declare module TcHmi.Functions.Beckhoff {
    /**
     * Concatenate multiple string values.
     * @param strings
     */
    function Concatenate(...strings: string[]): string;
}
//# sourceMappingURL=Concatenate.d.ts.map